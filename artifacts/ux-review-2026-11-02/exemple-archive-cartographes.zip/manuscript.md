# Les Cartographes de brume

Lecture dérivée ; les archives et versions retirées restent dans project.json.

## Tome I — L’Atlas des îles mouvantes

### I — La ville aux lanternes

#### La lettre sous la porte

La brume avait mangé les toits de Port-Lanterne avant même que les pêcheurs n’allument leurs lampes. Élise ouvrit sa fenêtre sur un monde sans contours. Au-dessous d’elle, les amarres grinçaient contre les anneaux du quai, comme si les bateaux rêvaient de partir seuls.

La lettre attendait sous la porte. Aucun timbre, aucune signature. Seulement trois mots, tracés de cette écriture inclinée qu’elle aurait reconnue entre mille : « *Ne suis pas le nord.* » Son père avait disparu sept ans plus tôt.

Elle retourna l’enveloppe. Une carte glissa sur le parquet. Les îles y formaient une constellation inconnue ; leurs noms changeaient lorsqu’elle détournait les yeux. Au centre, un phare minuscule semblait respirer.

— Tu comptes rester là jusqu’à la prochaine marée ? demanda Noé depuis l’escalier.

Élise replia la carte sans répondre. L’encre était tiède. Dehors, la cloche du port sonna six fois, puis une septième, bien que le mécanisme fût brisé depuis l’hiver.

Elle prit son carnet, la boussole de cuivre et le manteau bleu de sa mère. Pour la première fois depuis des années, elle n’emporta aucune carte connue.

Sur le seuil, une dernière phrase apparut au dos de l’enveloppe : « Les îles se souviennent de ceux qui les cherchent. »

#### Le marché des marées

Au marché, on vendait des boussoles, du sel et des histoires qui n’avaient pas encore eu lieu.

Mara attendait sous un auvent rouge. Sur sa table, trois coquillages tournaient lentement dans des directions différentes.

— Vous cherchez un phare, dit-elle. C’est commode. Lui aussi cherche quelqu’un.

Noé éclata de rire, mais Élise avait cessé de sourire. Dans la poche de son manteau, la carte venait de devenir glacée.

### II — Les îles qui dérivent

#### Une mer sans nord

Le troisième matin, les aiguilles cessèrent d’indiquer le nord. Elles pointaient toutes vers Élise.

Mara fit couper les voiles. À quelques mètres de la coque, une île avançait contre le courant, ses arbres penchés comme des voyageurs pressés.

— Ce n’est pas nous qui naviguons, murmura Noé. C’est le monde qui passe.

#### Le jardin des voix

Le jardin était plein de conversations anciennes. Chaque feuille chuchotait une phrase, chaque branche retenait un prénom.

Élise reconnut la voix de sa mère près d’un poirier sans fruits. Elle tendit la main, puis s’arrêta. Certaines portes ne devaient pas être ouvertes pour prouver qu’elles existaient.

Au pied de l’arbre, une lumière venait de dessiner le contour d’un phare.

### III — Le phare oublié

#### La chambre des cartes

La porte ne portait aucune serrure. Élise posa la paume sur le bois et sentit la chaleur d’un matin d’été.

Dans la chambre circulaire, des cartes couvraient les murs du sol au plafond. Certaines étaient faites de papier, d’autres de tissu, de lumière ou de silence.

Au milieu de la pièce, son père avait laissé une chaise vide. Sur le dossier, un manteau bleu attendait depuis sept ans.

#### Ce que garde la lumière

Le phare n’était pas un point fixe. Il était une promesse : celle de trouver un chemin lorsque tous les repères disparaissent.

Élise ouvrit la fenêtre. La brume entra sans bruit et se déplia sur le sol comme une carte neuve.

Derrière elle, Noé posa une tasse de thé sur la table.

— On rentre ?

Elle regarda les îles se déplacer au loin.

— Pas encore.

## Carnets — Fragments de l’archipel

### Notes de voyage

#### Journal de Mara — 17e marée

Je ne tiens plus le compte des îles. Je tiens celui des retours.

Aujourd’hui, une jeune femme est venue au marché avec les yeux de quelqu’un qui vient de recevoir une mauvaise nouvelle — ou une très ancienne bonne nouvelle.

Si elle retrouve le phare, il faudra lui dire la vérité sur les cartes. Peut-être pas toute la vérité. Pas encore.
